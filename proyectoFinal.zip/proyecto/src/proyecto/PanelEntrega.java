/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

import javax.swing.*;
import java.sql.Date;

public class PanelEntrega extends JPanel {
    private JTextField txtId, txtCliente, txtZona, txtFecha;
    private JButton btnAgregar, btnActualizar, btnEliminar, btnListar;
    private JTextArea txtArea;
    private EntregaDao dao;

    public PanelEntrega() {
        setLayout(null);

        JLabel lbl1 = new JLabel("ID Entrega:");
        lbl1.setBounds(20,20,100,30); add(lbl1);
        txtId = new JTextField(); txtId.setBounds(120,20,150,30); add(txtId);

        JLabel lbl2 = new JLabel("ID Cliente:");
        lbl2.setBounds(20,60,100,30); add(lbl2);
        txtCliente = new JTextField(); txtCliente.setBounds(120,60,150,30); add(txtCliente);

        JLabel lbl3 = new JLabel("ID Zona:");
        lbl3.setBounds(20,100,100,30); add(lbl3);
        txtZona = new JTextField(); txtZona.setBounds(120,100,150,30); add(txtZona);

        JLabel lbl4 = new JLabel("Fecha (YYYY-MM-DD):");
        lbl4.setBounds(20,140,150,30); add(lbl4);
        txtFecha = new JTextField(); txtFecha.setBounds(170,140,150,30); add(txtFecha);

        btnAgregar = new JButton("Agregar"); btnAgregar.setBounds(350,20,120,30); add(btnAgregar);
        btnActualizar = new JButton("Actualizar"); btnActualizar.setBounds(350,60,120,30); add(btnActualizar);
        btnEliminar = new JButton("Eliminar"); btnEliminar.setBounds(350,100,120,30); add(btnEliminar);
        btnListar = new JButton("Listar"); btnListar.setBounds(350,140,120,30); add(btnListar);

        txtArea = new JTextArea(); txtArea.setBounds(20,200,700,250); add(txtArea);

        dao = new EntregaDao();

        btnAgregar.addActionListener(e -> dao.insertarEntrega(
            Integer.parseInt(txtId.getText()),
            Integer.parseInt(txtCliente.getText()),
            Integer.parseInt(txtZona.getText()),
            Date.valueOf(txtFecha.getText())
        ));

        btnActualizar.addActionListener(e -> dao.actualizarEntrega(
            Integer.parseInt(txtId.getText()),
            Integer.parseInt(txtCliente.getText()),
            Integer.parseInt(txtZona.getText()),
            Date.valueOf(txtFecha.getText())
        ));

        btnEliminar.addActionListener(e -> dao.eliminarEntrega(
            Integer.parseInt(txtId.getText())
        ));

        btnListar.addActionListener(e -> {
            txtArea.setText("");
            dao.listarEntregas();
        });
    }
}

