package proyecto;

import proyecto.ClienteDao;
import javax.swing.*;
 
public class PanelClientes extends JPanel {
    private JTextField txtId, txtNombre, txtTipo, txtZona;
    private JButton btnAgregar, btnActualizar, btnEliminar, btnListar;
    private JTextArea txtArea;
    private ClienteDao dao;
 
    public PanelClientes() {
        setLayout(null);
 
        JLabel lbl1 = new JLabel("ID Cliente:");
        lbl1.setBounds(20,20,100,30); add(lbl1);
        txtId = new JTextField(); txtId.setBounds(120,20,150,30); add(txtId);
 
        JLabel lbl2 = new JLabel("Nombre:");
        lbl2.setBounds(20,60,100,30); add(lbl2);
        txtNombre = new JTextField(); txtNombre.setBounds(120,60,150,30); add(txtNombre);
 
        JLabel lbl3 = new JLabel("Tipo:");
        lbl3.setBounds(20,100,100,30); add(lbl3);
        txtTipo = new JTextField(); txtTipo.setBounds(120,100,150,30); add(txtTipo);
 
        JLabel lbl4 = new JLabel("Zona:");
        lbl4.setBounds(20,140,100,30); add(lbl4);
        txtZona = new JTextField(); txtZona.setBounds(120,140,150,30); add(txtZona);
 
        btnAgregar = new JButton("Agregar"); btnAgregar.setBounds(300,20,120,30); add(btnAgregar);
        btnActualizar = new JButton("Actualizar"); btnActualizar.setBounds(300,60,120,30); add(btnActualizar);
        btnEliminar = new JButton("Eliminar"); btnEliminar.setBounds(300,100,120,30); add(btnEliminar);
        btnListar = new JButton("Listar"); btnListar.setBounds(300,140,120,30); add(btnListar);
 
        txtArea = new JTextArea(); txtArea.setBounds(20,200,700,250); add(txtArea);
 
        dao = new ClienteDao();
 
        // Eventos
        btnAgregar.addActionListener(e -> {
            dao.insertarCliente(
                Integer.parseInt(txtId.getText()),
                txtNombre.getText(),
                txtTipo.getText(),
                txtZona.getText()
            );
        });
 
        btnActualizar.addActionListener(e -> {
            dao.actualizarCliente(
                Integer.parseInt(txtId.getText()),
                txtNombre.getText(),
                txtTipo.getText(),
                txtZona.getText()
            );
        });
 
        btnEliminar.addActionListener(e -> {
            dao.eliminarCliente(
                Integer.parseInt(txtId.getText())
            );
        });
 
        btnListar.addActionListener(e -> {
            txtArea.setText(""); // limpiar
            // Aquí puedes llamar listarClientes del DAO
            dao.listarClientes();
        });
    }
}

