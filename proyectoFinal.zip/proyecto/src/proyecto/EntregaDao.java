/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

import java.sql.*;

public class EntregaDao {

    public void insertarEntrega(int id, int idCliente, int idZona, java.sql.Date fecha) {
        try (Connection conn = ConexionOracle.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call insertar_entrega(?,?,?,?)}");
            stmt.setInt(1, id);
            stmt.setInt(2, idCliente);
            stmt.setInt(3, idZona);
            stmt.setDate(4, fecha);
            stmt.execute();
            System.out.println("✅ Entrega insertada.");
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public void actualizarEntrega(int id, int idCliente, int idZona, java.sql.Date fecha) {
        try (Connection conn = ConexionOracle.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call actualizar_entrega(?,?,?,?)}");
            stmt.setInt(1, id);
            stmt.setInt(2, idCliente);
            stmt.setInt(3, idZona);
            stmt.setDate(4, fecha);
            stmt.execute();
            System.out.println("✅ Entrega actualizada.");
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public void eliminarEntrega(int id) {
        try (Connection conn = ConexionOracle.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call eliminar_entrega(?)}");
            stmt.setInt(1, id);
            stmt.execute();
            System.out.println("✅ Entrega eliminada.");
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public void listarEntregas() {
        try (Connection conn = ConexionOracle.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call listar_entregas(?)}");
            stmt.registerOutParameter(1, oracle.jdbc.OracleTypes.CURSOR);
            stmt.execute();

            ResultSet rs = (ResultSet) stmt.getObject(1);
            while (rs.next()) {
                System.out.println(rs.getInt("id_entrega") + " - " +
                                   rs.getInt("id_cliente") + " - " +
                                   rs.getInt("id_zona") + " - " +
                                   rs.getDate("fecha_entrega"));
            }
        } catch (SQLException e) { e.printStackTrace(); }
    }
}

