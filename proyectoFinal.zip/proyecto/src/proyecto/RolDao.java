/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

import java.sql.*;

public class RolDao {

    public void insertarRol(int id, String nombreRol) {
        try (Connection conn = ConexionOracle.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call insertar_rol(?,?)}");
            stmt.setInt(1, id);
            stmt.setString(2, nombreRol);
            stmt.execute();
            System.out.println("✅ Rol insertado.");
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public void actualizarRol(int id, String nombreRol) {
        try (Connection conn = ConexionOracle.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call actualizar_rol(?,?)}");
            stmt.setInt(1, id);
            stmt.setString(2, nombreRol);
            stmt.execute();
            System.out.println("✅ Rol actualizado.");
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public void eliminarRol(int id) {
        try (Connection conn = ConexionOracle.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call eliminar_rol(?)}");
            stmt.setInt(1, id);
            stmt.execute();
            System.out.println("✅ Rol eliminado.");
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public void listarRoles() {
        try (Connection conn = ConexionOracle.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call listar_roles(?)}");
            stmt.registerOutParameter(1, oracle.jdbc.OracleTypes.CURSOR);
            stmt.execute();

            ResultSet rs = (ResultSet) stmt.getObject(1);
            while (rs.next()) {
                System.out.println(rs.getInt("id_rol") + " - " +
                                   rs.getString("nombre_rol"));
            }
        } catch (SQLException e) { e.printStackTrace(); }
    }
}
