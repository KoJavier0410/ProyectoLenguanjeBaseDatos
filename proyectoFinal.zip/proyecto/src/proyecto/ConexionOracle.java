package proyecto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author rosca
 */
public class ConexionOracle {
    private static Connection conn = null;

    public static Connection getConnection() {
        try {
            Class.forName("oracle.jdbc.OracleDriver");

            String url = "jdbc:oracle:thin:@localhost:1521:XE";

            String user = "proyecto";
            String password = "proyecto25";

            conn = DriverManager.getConnection(url, user, password);
            System.out.println("Conexion establecida con Oracle");

        } catch (ClassNotFoundException e) {
            System.err.println("No se encontró el driver JDBC: " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("Error en la conexión: " + e.getMessage());
        }
        return conn;
    }

    public static void main(String[] args) {
        try (Connection c = getConnection()) {
            if (c != null) {
                PreparedStatement ps = c.prepareStatement("SELECT 1 FROM dual");
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    System.out.println("Prueba exitosa, resultado: " + rs.getInt(1));
                }
                rs.close();
                ps.close();
            }
        } catch (SQLException e) {
            System.err.println("Error ejecutando consulta: " + e.getMessage());
        }
    }
}


