/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

import javax.swing.*;

public class FrmPrincipal extends JFrame {
    private JTabbedPane tabbedPane;

    public FrmPrincipal() {
        setTitle("Sistema de Gestión - Carnes Hikisa");
        setSize(900, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        tabbedPane = new JTabbedPane();
        tabbedPane.setBounds(10, 10, 860, 540);

        // Agregar los paneles
        tabbedPane.add("Clientes", new PanelClientes());
        tabbedPane.add("Roles", new PanelRol());
        tabbedPane.add("Usuarios", new PanelUsuario());
        tabbedPane.add("Zonas", new PanelZonaEntrega());
        tabbedPane.add("Entregas", new PanelEntrega());
        tabbedPane.add("Categorías", new PanelCategoria());
        tabbedPane.add("Productos", new PanelProducto());
        add(tabbedPane);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new FrmPrincipal().setVisible(true));
    }
}
