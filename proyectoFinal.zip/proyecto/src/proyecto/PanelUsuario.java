/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

import javax.swing.*;

public class PanelUsuario extends JPanel {
    private JTextField txtId, txtNombre, txtContrasena, txtIdRol;
    private JButton btnAgregar, btnActualizar, btnEliminar, btnListar;
    private JTextArea txtArea;
    private UsuarioDao dao;

    public PanelUsuario() {
        setLayout(null);

        JLabel lbl1 = new JLabel("ID Usuario:");
        lbl1.setBounds(20,20,100,30); add(lbl1);
        txtId = new JTextField(); txtId.setBounds(120,20,150,30); add(txtId);

        JLabel lbl2 = new JLabel("Nombre Usuario:");
        lbl2.setBounds(20,60,100,30); add(lbl2);
        txtNombre = new JTextField(); txtNombre.setBounds(120,60,150,30); add(txtNombre);

        JLabel lbl3 = new JLabel("Contraseña:");
        lbl3.setBounds(20,100,100,30); add(lbl3);
        txtContrasena = new JTextField(); txtContrasena.setBounds(120,100,150,30); add(txtContrasena);

        JLabel lbl4 = new JLabel("ID Rol:");
        lbl4.setBounds(20,140,100,30); add(lbl4);
        txtIdRol = new JTextField(); txtIdRol.setBounds(120,140,150,30); add(txtIdRol);

        btnAgregar = new JButton("Agregar"); btnAgregar.setBounds(300,20,120,30); add(btnAgregar);
        btnActualizar = new JButton("Actualizar"); btnActualizar.setBounds(300,60,120,30); add(btnActualizar);
        btnEliminar = new JButton("Eliminar"); btnEliminar.setBounds(300,100,120,30); add(btnEliminar);
        btnListar = new JButton("Listar"); btnListar.setBounds(300,140,120,30); add(btnListar);

        txtArea = new JTextArea(); txtArea.setBounds(20,200,700,250); add(txtArea);

        dao = new UsuarioDao();

        btnAgregar.addActionListener(e -> dao.insertarUsuario(
            Integer.parseInt(txtId.getText()), txtNombre.getText(),
            txtContrasena.getText(), Integer.parseInt(txtIdRol.getText())
        ));

        btnActualizar.addActionListener(e -> dao.actualizarUsuario(
            Integer.parseInt(txtId.getText()), txtNombre.getText(),
            txtContrasena.getText(), Integer.parseInt(txtIdRol.getText())
        ));

        btnEliminar.addActionListener(e -> dao.eliminarUsuario(
            Integer.parseInt(txtId.getText())
        ));

        btnListar.addActionListener(e -> {
            txtArea.setText("");
            dao.listarUsuarios();
        });
    }
}

