/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

import java.sql.*;

public class ZonaEntregaDao {

    public void insertarZona(int id, String nombreZona) {
        try (Connection conn = ConexionOracle.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call insertar_zona_entrega(?,?)}");
            stmt.setInt(1, id);
            stmt.setString(2, nombreZona);
            stmt.execute();
            System.out.println("✅ Zona insertada.");
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public void actualizarZona(int id, String nombreZona) {
        try (Connection conn = ConexionOracle.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call actualizar_zona_entrega(?,?)}");
            stmt.setInt(1, id);
            stmt.setString(2, nombreZona);
            stmt.execute();
            System.out.println("✅ Zona actualizada.");
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public void eliminarZona(int id) {
        try (Connection conn = ConexionOracle.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call eliminar_zona_entrega(?)}");
            stmt.setInt(1, id);
            stmt.execute();
            System.out.println("✅ Zona eliminada.");
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public void listarZonas() {
        try (Connection conn = ConexionOracle.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call listar_zonas_entrega(?)}");
            stmt.registerOutParameter(1, oracle.jdbc.OracleTypes.CURSOR);
            stmt.execute();

            ResultSet rs = (ResultSet) stmt.getObject(1);
            while (rs.next()) {
                System.out.println(rs.getInt("id_zona") + " - " +
                                   rs.getString("nombre_zona"));
            }
        } catch (SQLException e) { e.printStackTrace(); }
    }
}

