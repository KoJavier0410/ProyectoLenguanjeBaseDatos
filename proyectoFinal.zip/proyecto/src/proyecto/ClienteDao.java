/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

import proyecto.ConexionOracle;
import java.sql.*;
 
public class ClienteDao {
    public void insertarCliente(int id, String nombre, String tipo, String zona) {
        try (Connection conn = ConexionOracle.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call insertar_cliente(?,?,?,?)}");
            stmt.setInt(1, id);
            stmt.setString(2, nombre);
            stmt.setString(3, tipo);
            stmt.setString(4, zona);
            stmt.execute();
            System.out.println("✅ Cliente insertado.");
        } catch (SQLException e) { e.printStackTrace(); }
    }
 
    public void actualizarCliente(int id, String nombre, String tipo, String zona) {
        try (Connection conn = ConexionOracle.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call actualizar_cliente(?,?,?,?)}");
            stmt.setInt(1, id);
            stmt.setString(2, nombre);
            stmt.setString(3, tipo);
            stmt.setString(4, zona);
            stmt.execute();
            System.out.println("✅ Cliente actualizado.");
        } catch (SQLException e) { e.printStackTrace(); }
    }
 
    public void eliminarCliente(int id) {
        try (Connection conn = ConexionOracle.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call eliminar_cliente(?)}");
            stmt.setInt(1, id);
            stmt.execute();
            System.out.println("✅ Cliente eliminado.");
        } catch (SQLException e) { e.printStackTrace(); }
    }
 
    public void listarClientes() {
        try (Connection conn = ConexionOracle.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call listar_clientes(?)}");
            stmt.registerOutParameter(1, oracle.jdbc.OracleTypes.CURSOR);
            stmt.execute();
 
            ResultSet rs = (ResultSet) stmt.getObject(1);
            while (rs.next()) {
                System.out.println(rs.getInt("id_cliente") + " - " +
                                   rs.getString("nombre_cliente") + " - " +
                                   rs.getString("tipo_cliente") + " - " +
                                   rs.getString("zona_entrega"));
            }
        } catch (SQLException e) { e.printStackTrace(); }
    }
}

