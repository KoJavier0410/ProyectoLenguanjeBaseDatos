/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

import java.sql.*;

public class UsuarioDao {

    public void insertarUsuario(int id, String nombreUsuario, String contrasena, int idRol) {
        try (Connection conn = ConexionOracle.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call insertar_usuario(?,?,?,?)}");
            stmt.setInt(1, id);
            stmt.setString(2, nombreUsuario);
            stmt.setString(3, contrasena);
            stmt.setInt(4, idRol);
            stmt.execute();
            System.out.println("✅ Usuario insertado.");
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public void actualizarUsuario(int id, String nombreUsuario, String contrasena, int idRol) {
        try (Connection conn = ConexionOracle.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call actualizar_usuario(?,?,?,?)}");
            stmt.setInt(1, id);
            stmt.setString(2, nombreUsuario);
            stmt.setString(3, contrasena);
            stmt.setInt(4, idRol);
            stmt.execute();
            System.out.println("✅ Usuario actualizado.");
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public void eliminarUsuario(int id) {
        try (Connection conn = ConexionOracle.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call eliminar_usuario(?)}");
            stmt.setInt(1, id);
            stmt.execute();
            System.out.println("✅ Usuario eliminado.");
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public void listarUsuarios() {
        try (Connection conn = ConexionOracle.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call listar_usuarios(?)}");
            stmt.registerOutParameter(1, oracle.jdbc.OracleTypes.CURSOR);
            stmt.execute();

            ResultSet rs = (ResultSet) stmt.getObject(1);
            while (rs.next()) {
                System.out.println(rs.getInt("id_usuario") + " - " +
                                   rs.getString("nombre_usuario") + " - " +
                                   rs.getString("contrasena") + " - " +
                                   rs.getInt("id_rol"));
            }
        } catch (SQLException e) { e.printStackTrace(); }
    }
}

