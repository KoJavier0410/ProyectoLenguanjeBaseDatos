/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

import javax.swing.*;

public class PanelCategoria extends JPanel {
    private JTextField txtId, txtNombre;
    private JButton btnAgregar, btnActualizar, btnEliminar, btnListar;
    private JTextArea txtArea;
    private CategoriaDao dao;

    public PanelCategoria() {
        setLayout(null);

        JLabel lbl1 = new JLabel("ID Categoría:");
        lbl1.setBounds(20,20,120,30); add(lbl1);
        txtId = new JTextField(); txtId.setBounds(140,20,150,30); add(txtId);

        JLabel lbl2 = new JLabel("Nombre:");
        lbl2.setBounds(20,60,120,30); add(lbl2);
        txtNombre = new JTextField(); txtNombre.setBounds(140,60,150,30); add(txtNombre);

        btnAgregar = new JButton("Agregar"); btnAgregar.setBounds(320,20,120,30); add(btnAgregar);
        btnActualizar = new JButton("Actualizar"); btnActualizar.setBounds(320,60,120,30); add(btnActualizar);
        btnEliminar = new JButton("Eliminar"); btnEliminar.setBounds(320,100,120,30); add(btnEliminar);
        btnListar = new JButton("Listar"); btnListar.setBounds(320,140,120,30); add(btnListar);

        txtArea = new JTextArea(); txtArea.setBounds(20,200,700,250); add(txtArea);

        dao = new CategoriaDao();

        btnAgregar.addActionListener(e -> dao.insertarCategoria(
            Integer.parseInt(txtId.getText()), txtNombre.getText()
        ));

        btnActualizar.addActionListener(e -> dao.actualizarCategoria(
            Integer.parseInt(txtId.getText()), txtNombre.getText()
        ));

        btnEliminar.addActionListener(e -> dao.eliminarCategoria(
            Integer.parseInt(txtId.getText())
        ));

        btnListar.addActionListener(e -> {
            txtArea.setText("");
            dao.listarCategorias();
        });
    }
}

