/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

import java.sql.*;

public class CategoriaDao {

    public void insertarCategoria(int id, String nombre) {
        try (Connection conn = ConexionOracle.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call insertar_categoria(?,?)}");
            stmt.setInt(1, id);
            stmt.setString(2, nombre);
            stmt.execute();
            System.out.println("✅ Categoría insertada.");
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public void actualizarCategoria(int id, String nombre) {
        try (Connection conn = ConexionOracle.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call actualizar_categoria(?,?)}");
            stmt.setInt(1, id);
            stmt.setString(2, nombre);
            stmt.execute();
            System.out.println("✅ Categoría actualizada.");
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public void eliminarCategoria(int id) {
        try (Connection conn = ConexionOracle.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call eliminar_categoria(?)}");
            stmt.setInt(1, id);
            stmt.execute();
            System.out.println("✅ Categoría eliminada.");
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public void listarCategorias() {
        try (Connection conn = ConexionOracle.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call listar_categorias(?)}");
            stmt.registerOutParameter(1, oracle.jdbc.OracleTypes.CURSOR);
            stmt.execute();

            ResultSet rs = (ResultSet) stmt.getObject(1);
            while (rs.next()) {
                System.out.println(rs.getInt("id_categoria") + " - " +
                                   rs.getString("nombre_categoria"));
            }
        } catch (SQLException e) { e.printStackTrace(); }
    }
}

